package com.masai.configuration;

public interface SecurityContent {
	public static final String JWT_KEY="adityaaytidaadityaabhishekayushaswinchetan";
	public static final String JWT_HEADER = "Authorization";
}